export const bankMap = [
    { id: "1", value: 'กสิกรไทย', image: 'https://imagedelivery.net/QZ6TuL-3r02W7wQjQrv5DA/446b4b9c-af1e-47aa-e475-784f42d5a300/100' },
    { id: "2", value: 'ไทยพานิชย์', image: 'https://imagedelivery.net/QZ6TuL-3r02W7wQjQrv5DA/25ab88ca-e5c6-46d3-c65d-a951d8485400/100' },
    { id: "3", value: 'กรุงศรี', image: 'https://imagedelivery.net/QZ6TuL-3r02W7wQjQrv5DA/1e48feb2-d581-444e-b38d-395ffc3eb700/100' },
    { id: "4", value: 'กรุงไทย', image: 'https://imagedelivery.net/QZ6TuL-3r02W7wQjQrv5DA/793c2889-d87d-4bd7-65e4-7131faed5f00/100' },
    { id: "5", value: 'ออมสิน', image: 'https://imagedelivery.net/QZ6TuL-3r02W7wQjQrv5DA/370eda5c-ead4-4454-6981-724ee017b700/100' },
    { id: "6", value: 'ธนชาติ', image: 'https://imagedelivery.net/QZ6TuL-3r02W7wQjQrv5DA/7b242ada-faae-48af-418f-0601a40b0b00/100' },
];